document.addEventListener('DOMContentLoaded', function() {
    const openAccountBtn = document.querySelector('.log');
    openAccountBtn.addEventListener('click', function() {
        window.open('login.html', '_blank');
    });
});
document.addEventListener('DOMContentLoaded', function() {
    const openAccountBtn = document.querySelector('.open-account');
    openAccountBtn.addEventListener('click', function() {
        window.open('login.html', '_blank');
    });
});
document.addEventListener('DOMContentLoaded', function() {
    const openAccountBtn = document.querySelector('.open-account-btn');
    openAccountBtn.addEventListener('click', function() {
        window.open('login.html', '_blank');
    });
});