document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('password');
    const eyeIcon = document.querySelector('.fa-eye-slash');

    eyeIcon.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        eyeIcon.classList.toggle('fa-eye-slash');
        eyeIcon.classList.toggle('fa-eye');
    });

    passwordInput.addEventListener('input', function() {
        if (passwordInput.value === '') {
            eyeIcon.style.display = 'none';
        } else {
            eyeIcon.style.display = 'block';
        }
    });
});
let slideIndex = 0; 

    function showSlides() {
        let slides = document.getElementsByClassName("slider-image");


        for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }


        slides[slideIndex].style.display = "block";
    }


    function changeSlide(n) {
        let slides = document.getElementsByClassName("slider-image");


        slides[slideIndex].style.display = "none";


        slideIndex += n;


        if (slideIndex < 0) {
            slideIndex = slides.length - 1; 
        } else if (slideIndex >= slides.length) {
            slideIndex = 0; 
        }


        slides[slideIndex].style.display = "block";
    }


    showSlides();